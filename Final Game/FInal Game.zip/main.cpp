

//si - final

#ifdef _WINDOWS
#include <GL/glew.h>
#endif
#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>

#include "ShaderProgram.h"
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"

#define STB_IMAGE_IMPLEMENTATION //required for stb image library
#include "stb_image.h"

#ifdef _WINDOWS
#define RESOURCE_FOLDER
#else
#define RESOURCE_FOLDER "NYUCodebase.app/Contents/Resources/"
#endif

#include <vector>
#include <unistd.h>
#include <cstdlib>
#include <ctime>

#include <SDL_mixer.h>


ShaderProgram program;
ShaderProgram texturedProgram;

glm::mat4 modelMatrix = glm::mat4(1.0f);
glm::mat4 viewMatrix = glm::mat4(1.0f);
glm::mat4 projectionMatrix = glm::mat4(1.0f);

#define FIXED_TIMESTEP 0.0166666f
#define MAX_TIMESTEPS 6
float accumulator = 0.0f;

//float velocityX = 3.0f;
//float velocityY = 3.0f;
//float accelerationX = 20.5f;
//float accelerationY = 20.5f;
//float frictionX = 0.5f;
//float frictionY = 0.5f;

float velocityX = 0.0f;
float velocityY = 0.0f;
float accelerationX = 1.5f;
float accelerationY = 1.5f;
float frictionX = 1.0f;
float frictionY = 1.0f;

#define TILE_SIZE 0.15
#define PLAYER_SIZE 0.1

int gameLevel = 0;


SDL_Window* displayWindow;

// linear interpolation (curve fitting); value changes smoothly
float lerp(float v0, float v1, float t) {
    return (1.0-t)*v0 + t*v1;
}

GLuint LoadTexture(const char *filePath) {
    
    int w,h,comp;
    
    unsigned char* image = stbi_load(filePath, &w, &h, &comp, STBI_rgb_alpha);
    
    if(image == NULL) { //check if loaded
        std::cout << "Unable to load image. Make sure the path is correct\n";
        assert(false); // triggers an exception; no point in continuing program
    }
    
    GLuint retTexture;
    glGenTextures(1, &retTexture);
    glBindTexture(GL_TEXTURE_2D, retTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    
    stbi_image_free(image);
    return retTexture;
}

void DrawText2(ShaderProgram &program, int fontTexture, std::string text, float size, float spacing) {
    float character_size = 1.0/16.0f;
    std::vector<float> vertexData;
    std::vector<float> texCoordData;
    for(int i=0; i < text.size(); i++) {
        int spriteIndex = (int)text[i];
        float texture_x = (float)(spriteIndex % 16) / 16.0f;
        float texture_y = (float)(spriteIndex / 16) / 16.0f;
        vertexData.insert(vertexData.end(), {
            ((size+spacing) * i) + (-0.5f * size), 0.5f * size,
            ((size+spacing) * i) + (-0.5f * size), -0.5f * size,
            ((size+spacing) * i) + (0.5f * size), 0.5f * size,
            ((size+spacing) * i) + (0.5f * size), -0.5f * size,
            ((size+spacing) * i) + (0.5f * size), 0.5f * size,
            ((size+spacing) * i) + (-0.5f * size), -0.5f * size,
        });
        texCoordData.insert(texCoordData.end(), {
            texture_x, texture_y,
            texture_x, texture_y + character_size,
            texture_x + character_size, texture_y, //
            texture_x + character_size, texture_y + character_size,
            texture_x + character_size, texture_y,
            texture_x, texture_y + character_size,
        }); }
    glBindTexture(GL_TEXTURE_2D, fontTexture);
    
    glUseProgram(program.programID);
    
    glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoordData.data());
    glEnableVertexAttribArray(program.texCoordAttribute);
    glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertexData.data());
    glEnableVertexAttribArray(program.positionAttribute);
    glDrawArrays(GL_TRIANGLES, 0, (int) text.size()*6);
}

void DrawText(ShaderProgram &program, int fontTexture, std::string text, float size, float spacing, float Tx, float Ty, float Sx = 1.0f, float Sy = 1.0f) {
    float character_size = 1.0/16.0f;
    std::vector<float> vertexData;
    std::vector<float> texCoordData;
    for(int i=0; i < text.size(); i++) {
        int spriteIndex = (int)text[i];
        float texture_x = (float)(spriteIndex % 16) / 16.0f;
        float texture_y = (float)(spriteIndex / 16) / 16.0f;
        vertexData.insert(vertexData.end(), {
            ((size+spacing) * i) + (-0.5f * size), 0.5f * size,
            ((size+spacing) * i) + (-0.5f * size), -0.5f * size,
            ((size+spacing) * i) + (0.5f * size), 0.5f * size,
            ((size+spacing) * i) + (0.5f * size), -0.5f * size,
            ((size+spacing) * i) + (0.5f * size), 0.5f * size,
            ((size+spacing) * i) + (-0.5f * size), -0.5f * size,
        });
        texCoordData.insert(texCoordData.end(), {
            texture_x, texture_y,
            texture_x, texture_y + character_size,
            texture_x + character_size, texture_y, //
            texture_x + character_size, texture_y + character_size,
            texture_x + character_size, texture_y,
            texture_x, texture_y + character_size,
        }); }
    
    glBindTexture(GL_TEXTURE_2D, fontTexture);
    
    glUseProgram(program.programID);
    
    modelMatrix = glm::mat4(1.0f);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(Tx,Ty, 0.0f));
    modelMatrix = glm::scale(modelMatrix, glm::vec3(Sx, Sy, 1.0f));
    program.SetModelMatrix(modelMatrix);
    
 glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoordData.data());
    glEnableVertexAttribArray(program.texCoordAttribute);
    glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertexData.data());
    glEnableVertexAttribArray(program.positionAttribute);
    glDrawArrays(GL_TRIANGLES, 0, (int) text.size()*6);
}

class Entity{
public:
    
    Entity();
    void DrawSprite(ShaderProgram &program, int index, int spriteCountX,int spriteCountY, float Tx, float Ty, float Sx, float Sy);
    
    glm::vec3 position;
    glm::vec3 velocity;
    glm::vec3 size;
    
    float xPos;
    float yPos;
    
    float width;
    float height;
    
    float health;
    float rotation;
    
    bool collision = false;
    bool collision2 = false;
    
    bool isWall = false;
    bool isLava = false;
    
    int score = 0;
    
};


Entity::Entity () {
    
}

void Entity::DrawSprite(ShaderProgram &program, int index, int spriteCountX,int spriteCountY, float Tx, float Ty, float Sx, float Sy) {
    
    float u = (float)(((int)index) % spriteCountX) / (float) spriteCountX;
    float v = (float)(((int)index) / spriteCountY) / (float) spriteCountY;
    float spriteWidth = 1.0/(float)spriteCountX;
    float spriteHeight = 1.0/(float)spriteCountY;
    
    float texCoords[] = {
        u, v+spriteHeight,
        u+spriteWidth, v,
        u, v,
        u+spriteWidth, v,
        u, v+spriteHeight,
        u+spriteWidth, v+spriteHeight};
    
    float vertices[] = {-0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, 0.5f,  -0.5f,-0.5f, 0.5f, -0.5f};
    
    glUseProgram(program.programID);
    
    if (collision == true) {
        program.SetColor( 0.65, 0.0f, 0.0f, 1.0f); //red
    }
   if (collision2 == true) {
        program.SetColor( 0.0f, 0.0f, 0.65f, 1.0f); //blue
    }
    
    

    modelMatrix = glm::mat4(1.0f);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(Tx,Ty, 0.0f));
    modelMatrix = glm::scale(modelMatrix, glm::vec3(Sx, Sy, 1.0f));
    program.SetModelMatrix(modelMatrix);
    
    glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
    glEnableVertexAttribArray(program.texCoordAttribute);
    glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
    glEnableVertexAttribArray(program.positionAttribute);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    
    program.SetColor( 1.0f, 1.0f, 1.0f, 1.0f);
}


void DrawTexture(ShaderProgram &program, float Tx, float Ty, float Sx, float Sy){
    
    modelMatrix = glm::mat4(1.0f);
    modelMatrix = glm::translate(modelMatrix, glm::vec3(Tx,Ty, 0.0f));
    modelMatrix = glm::scale(modelMatrix, glm::vec3(Sx, Sy, 1.0f));
    program.SetModelMatrix(modelMatrix);
    
    float vertices1[] = {-0.5, -0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5};
    glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices1);
    glEnableVertexAttribArray(program.positionAttribute);
    
    float texCoords1[] = {0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0};
    glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords1);
    glEnableVertexAttribArray(program.texCoordAttribute);
    
    glDrawArrays(GL_TRIANGLES, 0, 6);
    
}

////gamestates
//class MainMenu {
//
//    //text
//public:
//    Entity welcome;
//};

/////////////////////////////////////////

int main(int argc, char *argv[])
{
    SDL_Init(SDL_INIT_VIDEO);
    displayWindow = SDL_CreateWindow("My Game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 800, SDL_WINDOW_OPENGL);
    SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
    SDL_GL_MakeCurrent(displayWindow, context);
    
#ifdef _WINDOWS
    
    glewInit();
#endif
    
    //SETUP
    glViewport(0, 0, 1280, 800);
    
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    projectionMatrix = glm::ortho(-1.777f, 1.777f, -1.0f, 1.0f, -1.0f, 1.0f);

  
    program.Load(RESOURCE_FOLDER"vertex.glsl", RESOURCE_FOLDER"fragment.glsl");
    texturedProgram.Load(RESOURCE_FOLDER"vertex_textured.glsl", RESOURCE_FOLDER"fragment_textured.glsl");
    
    //background color
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    
    //time keeping
    float ticks;
    float elapsedTime = 0;
    float lastFrameTicks = 0;
    
    float screenShakeValue = 0;
    bool shake = false;
    
    
    GLuint LoadTexture(const char *filePath);
    int textTexture = LoadTexture(RESOURCE_FOLDER"textsheet.png");
    int wallTexture = LoadTexture(RESOURCE_FOLDER"wall.png");
    int lavaTexture = LoadTexture(RESOURCE_FOLDER"lava2.jpeg");
    int glowTexture = LoadTexture(RESOURCE_FOLDER"glowsheet.png");

    // prep screens
    //MainMenu mainMenu;
    
    enum GameMode { STATE_MAIN_MENU, STATE_GAME_LEVEL, STATE_GAME_LEVEL_2, STATE_GAME_LEVEL_3, STATE_QUIT, STATE_END, STATE_STOP, STATE_COMPLETE};
    GameMode mode;
    
    mode = STATE_MAIN_MENU;
    int gameLevel;
    
    Entity player;
    Entity player2;

    
    int win = 0;
    
    player.width = 0.1;
    player.height = 0.1;
    
    player2.width =  0.1;
    player2.height = 0.1;

    player.xPos = - 1.5f;
    player2.xPos = 1.5f;

    int tiles_row = 20 * 2;
    int tiles_col = 36 * 2;
    Entity tiles[tiles_row][tiles_col];
    
    float x = - 1.7777;
    float y = - 1.0;

    for(int i = 0; i < tiles_row; i++) {
        y += 0.05;
        for(int j = 0; j < tiles_col; j++){
        
            tiles[i][j].width = 0.05;
            tiles[i][j].height = 0.05;
        
            tiles[i][j].yPos = y;
            tiles[i][j].xPos = x;

            
            x += 0.05;
        }
        x = -1.7777;
        
    }
    
//PLAY SOUND
    
    Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 4096 );
    Mix_Chunk *ping1;
    ping1 = Mix_LoadWAV( RESOURCE_FOLDER "ping1.wav");
    Mix_Chunk *ping2;
    ping2 = Mix_LoadWAV( RESOURCE_FOLDER "ping2.wav");
    Mix_Chunk *burn;
    burn = Mix_LoadWAV( RESOURCE_FOLDER "burn.wav");
    
    
    Mix_Music *music;
    music = Mix_LoadMUS( RESOURCE_FOLDER "pongmusic.wav" );
    
    
    Mix_PlayMusic(music, -1);
    Mix_VolumeMusic(3);

    
    //////////////
    SDL_Event event;
    bool done = false;
    while (!done) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
                done = true;
            } else if(event.key.keysym.scancode == SDL_SCANCODE_SPACE) {
            }
        }
        
        screenShakeValue = 0;
        float screenShakeIntensity = 0;
        
        glClear(GL_COLOR_BUFFER_BIT);
        glUseProgram(texturedProgram.programID);
        
        ticks = (float)SDL_GetTicks()/1000.0f;
        elapsedTime = ticks - lastFrameTicks;
        lastFrameTicks = ticks;
        

//        elapsedTime += accumulator;
//        if(elapsedTime < FIXED_TIMESTEP) {
//            accumulator = elapsedTime;
//            continue;
//        }
//        while(elapsedTime >= FIXED_TIMESTEP) {
//            //Update(FIXED_TIMESTEP);
//            elapsedTime -= FIXED_TIMESTEP;
//        }
//        accumulator = elapsedTime;

        
        const Uint8 *keys = SDL_GetKeyboardState(NULL);
        
        texturedProgram.SetProjectionMatrix(projectionMatrix);
        texturedProgram.SetViewMatrix(viewMatrix);
        
        
        if(keys[SDL_SCANCODE_Q]){
            
            mode = STATE_QUIT;
            
        }
            
            if (mode == STATE_QUIT)
            {
                
                modelMatrix = glm::mat4(1.0f);
                modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.5f,0.0f,0.0f));
                
                texturedProgram.SetModelMatrix(modelMatrix);
                texturedProgram.SetProjectionMatrix(projectionMatrix);
                texturedProgram.SetViewMatrix(viewMatrix);
                
                DrawText2(texturedProgram, textTexture, "You quit the game.", 0.15f, 0.0f);
                
                modelMatrix = glm::mat4(1.0f);
                modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.5f,-0.2f,0.0f));
                
                texturedProgram.SetModelMatrix(modelMatrix);
                texturedProgram.SetProjectionMatrix(projectionMatrix);
                texturedProgram.SetViewMatrix(viewMatrix);
                
                DrawText2(texturedProgram, textTexture, "Press ENTER to restart", 0.15f, 0.0f);
            }


        
        if( mode == STATE_MAIN_MENU) {
            
//            DrawText(texturedProgram, textTexture, "This is a game", 0.15, 0, -1.5, 0.0);
//            DrawText(texturedProgram, textTexture, "Press enter to start", 0.1, 0, -1.5, -0.2);
            
            
            modelMatrix = glm::mat4(1.0f);
            modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.5f,0.0f,0.0f));
            
            texturedProgram.SetModelMatrix(modelMatrix);
            texturedProgram.SetProjectionMatrix(projectionMatrix);
            texturedProgram.SetViewMatrix(viewMatrix);
            
            DrawText2(texturedProgram, textTexture, "This is a game", 0.15f, 0.0f);
            
            modelMatrix = glm::mat4(1.0f);
            modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.5f,-0.2f,0.0f));
            texturedProgram.SetModelMatrix(modelMatrix);

            DrawText2(texturedProgram, textTexture, "Press ENTER to start", 0.1f, 0.0f);

        }
        
        
     
       
        
        if(keys[SDL_SCANCODE_2])
        {
            mode = STATE_GAME_LEVEL_2;
        }

        
        if (mode == STATE_GAME_LEVEL_2) {
        
            
            Mix_PlayChannel( -1, ping2, 0);

            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    
                    if (tiles[i][j].collision){
                        
                        player.score++;
                    }
                    
                    if (tiles[i][j].collision2) {
                        
                        player2.score++;
                        
                    }
                }
            }
            
            
            if (player.score > player2.score) {
                
                std::cout << "player 1 wins!" << player.score << "\n";
                win = 1;
                
            }
            
            else {
                
                win = 2;
                std::cout << "player 2 wins!" << player.score << "\n";
            }
            
            
            //loser tiles become walls
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    
                    if (win ==  1){
                    
                        if (tiles[i][j].collision2) {
                            
                            tiles[i][j].isWall = true;
                            
                        }
                    }
                    
                    else{
                        
                        if (tiles[i][j].collision) {
                            
                            tiles[i][j].isWall = true;
                            
                        }
                        
                    }
                    
                }
            }
        
            
            std::cout << "player1: " << player.score << "\n";
            std::cout << "player2: " << player2.score;
            
            
            //reset all collision booleansp to start level with all white tiles
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){


                    tiles[i][j].collision = false;
                    tiles[i][j].collision2 = false;

                }
            }

            
            mode = STATE_GAME_LEVEL;

        }
        
        
        if(keys[SDL_SCANCODE_3])
        {
            mode = STATE_GAME_LEVEL_3;
        }

        
        if (mode == STATE_GAME_LEVEL_3) {
            
           
            Mix_PlayChannel( -1, ping2, 0);

            gameLevel = 3;
            
            
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){

                    
                    if (tiles[i][j].collision){
                        
                        player.score++;
                    }
                    
                    if (tiles[i][j].collision2) {
                        
                        player2.score++;
                        
                    }
                  
                }
            }
        
         

            std::cout << "after2player1: " << player.score << "\n";
            std::cout << " after2player2: " << player2.score;
            
            if (player.score > player2.score) {
                
                std::cout << "player 1 wins!" << player.score << "\n";
                win = 1;
                
            }
            
            else {
                
                win = 2;
                std::cout << "player 2 wins!" << player.score << "\n";
            }
            
            
            //loser tiles become lava
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    
                    if (win ==  1){
                        
                        if (tiles[i][j].collision2) {
                            
                            tiles[i][j].isLava = true;
                            
                        }
                    }
                    
                    else{
                        
                        if (tiles[i][j].collision) {
                            
                            tiles[i][j].isLava = true;
                            
                        }
                        
                    }
                    
                }
            }
            
            
            mode = STATE_GAME_LEVEL;

        }

        if(keys[SDL_SCANCODE_0])
        {
            mode = STATE_END;
        }
        
        
        if (mode == STATE_END) {
            
            
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){

                    
                    if (tiles[i][j].collision){
                        
                        player.score++;
                    }
                    
                    if (tiles[i][j].collision2) {
                        
                        player2.score++;
                        
                    }
                }
            }
            
            std::cout << "endplayer1: " << player.score << "\n";
            std::cout << " endplayer2: " << player2.score;
            
            if (player.score > player2.score) {
                
                std::cout << "player 1 wins!" << player.score << "\n";
                
            }
            
            else {std::cout << "player 2 wins!" << player.score << "\n";
            }
            
            mode = STATE_STOP;
            
        }
        
        
        
        if(keys[SDL_SCANCODE_C])
        {
            mode = STATE_COMPLETE;
        }
        
        
        if (mode == STATE_COMPLETE){
            
           Mix_PlayChannel( -1, ping1, 0);

            gameLevel = 999;
            
            modelMatrix = glm::mat4(1.0f);
            modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.5f,0.0f,0.0f));
            
            texturedProgram.SetModelMatrix(modelMatrix);
            texturedProgram.SetProjectionMatrix(projectionMatrix);
            texturedProgram.SetViewMatrix(viewMatrix);
            
            if (win == 1) {
                DrawText2(texturedProgram, textTexture, "Player 1 wins!", 0.15f, 0.0f);
            }
            
            else {
                
                DrawText2(texturedProgram, textTexture, "Player 2 wins!", 0.15f, 0.0f);
            }
    
            
            modelMatrix = glm::mat4(1.0f);
            modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.5f,-0.2f,0.0f));
            texturedProgram.SetModelMatrix(modelMatrix);
            
            DrawText2(texturedProgram, textTexture, "Press ENTER to play again", 0.1f, 0.0f);
            
            
            modelMatrix = glm::mat4(1.0f);
            modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.5f,-0.4f,0.0f));
            texturedProgram.SetModelMatrix(modelMatrix);
            
            DrawText2(texturedProgram, textTexture, "Press Q to Quit", 0.1f, 0.0f);
            
            
        }
            
    
        if (mode == STATE_STOP) {   }
        
        if(keys[SDL_SCANCODE_RETURN] || keys[SDL_SCANCODE_R])
        {
            gameLevel = 0;
            mode = STATE_GAME_LEVEL;
        }
        
        if (gameLevel != 999) {
        
        if (mode == STATE_GAME_LEVEL) {
            

            if (mode != STATE_QUIT ) {
                
//                Mix_VolumeChunk(ping1, 0);
//                Mix_VolumeChunk(ping2, 0);

            
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    if(tiles[i][j].isWall) {
                        glBindTexture(GL_TEXTURE_2D, wallTexture);
                        DrawTexture(texturedProgram,tiles[i][j].xPos, tiles[i][j].yPos,tiles[i][j].width, tiles[i][j].height);
                        
                    }
                    
                    else if (tiles[i][j].isLava){
                        glBindTexture(GL_TEXTURE_2D, lavaTexture);
                        DrawTexture(texturedProgram,tiles[i][j].xPos, tiles[i][j].yPos,tiles[i][j].width, tiles[i][j].height);
                        
                    }
                    
                    else {
                        glBindTexture(GL_TEXTURE_2D, glowTexture);
                        tiles[i][j].DrawSprite(program, 1, 6, 4, tiles[i][j].xPos, tiles[i][j].yPos, tiles[i][j].width, tiles[i][j].height);
                    }
                }
            }
            
    
            //collision test for player 1
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                
                float distanceX = abs(tiles[i][j].xPos - player.xPos) - ((player.width + tiles[i][j].width)/2);
                
                float distanceY = abs(tiles[i][j].yPos - player.yPos) - ((player.height + tiles[i][j].height)/2);
                
                if(distanceX < 0 && distanceY < 0){
                  tiles[i][j].collision = true;
                   tiles[i][j].collision2 = false;
                    
                    
                    //Mix_PlayChannel( -1, ping1, 0);

                }
            }
            }
            
            //collision test for player 2
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    float distanceX = abs(tiles[i][j].xPos - player2.xPos) - ((player2.width + tiles[i][j].width)/2);
                    
                    float distanceY = abs(tiles[i][j].yPos - player2.yPos) - ((player2.height + tiles[i][j].height)/2);
                    
                    if(distanceX < 0 && distanceY < 0){
                        tiles[i][j].collision2 = true;
                        tiles[i][j].collision = false;
                        
                        
                        //Mix_PlayChannel( -1, ping2, 0);

                    }
                }
            }
            

            glBindTexture(GL_TEXTURE_2D, glowTexture);


            
            //move & draw player 1
            if(keys[SDL_SCANCODE_A]) {
                if(player.xPos - player.width/2 > -1.777f) {
                    velocityX = lerp(velocityX, 0.0f, elapsedTime * frictionX);
                    velocityX += accelerationX * elapsedTime;
                    player.xPos -= velocityX * elapsedTime  * 3.00;
                }
                
                else{ player.xPos = 1.8; }

            }
            
            //test tiles to the left
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    if (tiles[i][j].isWall == true) {
                        
                        float distanceX = abs(tiles[i][j].xPos - player.xPos) - ((player.width + tiles[i][j].width)/2);
                        
                        float distanceY = abs(tiles[i][j].yPos - player.yPos) - ((player.height + tiles[i][j].height)/2);
                        
                        if(distanceX < 0 && distanceY < 0){
                            
                            float penetration = fabs((player.xPos - tiles[i][j].xPos) - player.width/2 - tiles[i][j].width/2);
                            
                            player.xPos += penetration + 0.005;
                        }
                    }
                    
                }
            }
            
            
             if(keys[SDL_SCANCODE_D]) {
                if(player.xPos + player.width/2 < 1.777f) {
                    velocityX = lerp(velocityX, 0.0f, elapsedTime * frictionX);
                    velocityX += accelerationX * elapsedTime;
                    player.xPos += velocityX * elapsedTime * 3.00;
                }
                 
                else{ player.xPos = - 1.8; }

            }
            
            
            //test tiles on the right
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    if (tiles[i][j].isWall == true) {
                        
                        float distanceX = abs(tiles[i][j].xPos - player.xPos) - ((player.width + tiles[i][j].width)/2);
                        
                        float distanceY = abs(tiles[i][j].yPos - player.yPos) - ((player.height + tiles[i][j].height)/2);
                        
                        if(distanceX < 0 && distanceY < 0){
                            
                            float penetration = fabs((player.xPos - tiles[i][j].xPos) - player.width/2 - tiles[i][j].width/2);
                            
                            player.xPos -= penetration - 0.005;
                        }
                    }
                    
                }
            }
            
             if(keys[SDL_SCANCODE_W]) {
                if(player.yPos + player.height/2 < 1.0f) {
                    velocityY = lerp(velocityY, 0.0f, elapsedTime * frictionY);
                    velocityY += accelerationY * elapsedTime;
                    player.yPos += velocityY * elapsedTime  * 3.00;
                }
                 
                else{ player.yPos = - 1.1; }

            }
            
            
            //test tiles above
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    if (tiles[i][j].isWall == true) {
                        
                        float distanceX = abs(tiles[i][j].xPos - player.xPos) - ((player.width + tiles[i][j].width)/2);
                        
                        float distanceY = abs(tiles[i][j].yPos - player.yPos) - ((player.height + tiles[i][j].height)/2);
                        
                        if(distanceX < 0 && distanceY < 0){
                            
                            float penetration = fabs((player.yPos - tiles[i][j].yPos) - player.height/2 - tiles[i][j].height/2);
                            
                            player.yPos -= penetration - 0.005;
                        }
                    }
                    
                }
            }
            
             if(keys[SDL_SCANCODE_S]) {
                if(player.yPos - player.height/2 > -1.0f) {
                    velocityY = lerp(velocityY, 0.0f, elapsedTime * frictionY);
                    velocityY += accelerationY * elapsedTime;
                    player.yPos -= velocityY * elapsedTime * 3.00 ;
                }
                 
                else{ player.yPos = 1.1; }

            }
            
            //test tiles below
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    if (tiles[i][j].isWall == true) {
                        
                        float distanceX = abs(tiles[i][j].xPos - player.xPos) - ((player.width + tiles[i][j].width)/2);
                        
                        float distanceY = abs(tiles[i][j].yPos - player.yPos) - ((player.height + tiles[i][j].height)/2);
                        
                        if(distanceX < 0 && distanceY < 0){
                            
                            float penetration = fabs((player.yPos - tiles[i][j].yPos) - player.height/2 - tiles[i][j].height/2);
                            
                            player.yPos += penetration + 0.005;
                        }
                    }
                    
                }
            }
            
            
//move & draw player 2
            if(keys[SDL_SCANCODE_LEFT]) {
                if(player2.xPos - player2.width/2 > -1.777f) {
                    velocityX = lerp(velocityX, 0.0f, elapsedTime * frictionX);
                    velocityX += accelerationX * elapsedTime;
                    player2.xPos -= velocityX * elapsedTime * 3.00;
                }
                
                else{ player2.xPos = 1.8; }
            }
            
            
            //test tiles to the left
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    if (tiles[i][j].isWall == true) {
                        
                        float distanceX = abs(tiles[i][j].xPos - player2.xPos) - ((player2.width + tiles[i][j].width)/2);
                        
                        float distanceY = abs(tiles[i][j].yPos - player2.yPos) - ((player2.height + tiles[i][j].height)/2);
                        
                        if(distanceX < 0 && distanceY < 0){
                            
                            float penetration = fabs((player2.xPos - tiles[i][j].xPos) - player2.width/2 - tiles[i][j].width/2);
                            
                            player2.xPos += penetration + 0.005;
                        }
                    }
                    
                }
            }
            
            
            
            if(keys[SDL_SCANCODE_RIGHT]) {
                if(player2.xPos + player2.width/2 < 1.777f) {
                    velocityX = lerp(velocityX, 0.0f, elapsedTime * frictionX);
                    velocityX += accelerationX * elapsedTime;
                    player2.xPos += velocityX * elapsedTime * 3.00;
                }
                
                else{ player2.xPos = - 1.8; }

            }
            
            //test tiles on the right
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    if (tiles[i][j].isWall == true) {
                        
                        float distanceX = abs(tiles[i][j].xPos - player2.xPos) - ((player2.width + tiles[i][j].width)/2);
                        
                        float distanceY = abs(tiles[i][j].yPos - player2.yPos) - ((player2.height + tiles[i][j].height)/2);
                        
                        if(distanceX < 0 && distanceY < 0){
                            
                            float penetration = fabs((player2.xPos - tiles[i][j].xPos) - player2.width/2 - tiles[i][j].width/2);
                            
                            player2.xPos -= penetration - 0.005;
                        }
                    }
                    
                }
            }
            
            if(keys[SDL_SCANCODE_UP]) {
                if(player2.yPos + player2.height/2 < 1.0f) {
                    velocityY = lerp(velocityY, 0.0f, elapsedTime * frictionY);
                    velocityY += accelerationY * elapsedTime;
                    player2.yPos += velocityY * elapsedTime * 3.00;
                }
                
                else{ player2.yPos = - 1.1; }

            }
            
            
            //test tiles above
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    if (tiles[i][j].isWall == true) {
                        
                        float distanceX = abs(tiles[i][j].xPos - player2.xPos) - ((player2.width + tiles[i][j].width)/2);
                        
                        float distanceY = abs(tiles[i][j].yPos - player2.yPos) - ((player2.height + tiles[i][j].height)/2);
                        
                        if(distanceX < 0 && distanceY < 0){
                            
                            float penetration = fabs((player2.yPos - tiles[i][j].yPos) - player2.height/2 - tiles[i][j].height/2);
                            
                            player2.yPos -= penetration - 0.005;
                        }
                    }
                    
                }
            }
            

            
            if(keys[SDL_SCANCODE_DOWN]) {
                if(player2.yPos - player2.height/2 > -1.0f) {
                    velocityY = lerp(velocityY, 0.0f, elapsedTime * frictionY);
                    velocityY += accelerationY * elapsedTime;
                    player2.yPos -= velocityY * elapsedTime * 3.00;
                }
                
                else{ player2.yPos =  1.1; }

            }
            
            
            //test tiles below
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){
                    
                    if (tiles[i][j].isWall == true) {
                        
                        float distanceX = abs(tiles[i][j].xPos - player2.xPos) - ((player2.width + tiles[i][j].width)/2);
                        
                        float distanceY = abs(tiles[i][j].yPos - player2.yPos) - ((player2.height + tiles[i][j].height)/2);
                        
                          if(distanceX < 0 && distanceY < 0){
                              
                            float penetration = fabs((player2.yPos - tiles[i][j].yPos) - player2.height/2 - tiles[i][j].height/2);
                              
                              player2.yPos += penetration + 0.005;
                          }
                        }
                    
                    }
                }
        

                
            if (gameLevel = 3) {
            // test collision with lava for both players
            for(int i = 0; i < tiles_row; i++) {
                for(int j = 0; j < tiles_col; j++){


                    if (tiles[i][j].isLava) {

                        
                        float distanceX = abs(tiles[i][j].xPos - player.xPos) - ((player.width + tiles[i][j].width)/2);
                        
                        float distanceY = abs(tiles[i][j].yPos - player.yPos) - ((player.height + tiles[i][j].height)/2);

                        float distanceX2 = abs(tiles[i][j].xPos - player2.xPos) - ((player2.width + tiles[i][j].width)/2);

                        float distanceY2 = abs(tiles[i][j].yPos - player2.yPos) - ((player2.height + tiles[i][j].height)/2);
                        

                        if((distanceX < 0 && distanceY < 0)){
                            
                            player.score -= 5;
                            
                           // Mix_VolumeChunk(shootSound, 10); // set sound volume (from 0 to 128)
                            
                            
                            Mix_PlayChannel( -1, burn, 0);

                            
                            screenShakeValue += elapsedTime;
                            //screenShakeIntensity += elapsedTime + 0.3;
                            
                        }
                        
                        if( (distanceX2 < 0 && distanceY2 < 0) ){
                            
                            player2.score -= 5;
                            
                            // Mix_VolumeChunk(shootSound, 10); // set sound volume (from 0 to 128)
                            
                            Mix_PlayChannel( -1, burn, 0);
                            
                        }
                    }
                }
            }
                    
        }

            player.DrawSprite(texturedProgram, 49, 12, 8, player.xPos, player.yPos, player.width, player.height );
                
            player2.DrawSprite(texturedProgram, 55, 12, 8, player2.xPos, player2.yPos, player2.width, player2.height );
                
            
                
      

           
        }
        }
        }
        
        
       
        /* end of game modes*/
        
      

  
        texturedProgram.SetViewMatrix(viewMatrix);
        texturedProgram.SetProjectionMatrix(projectionMatrix);
        program.SetProjectionMatrix(projectionMatrix);
        program.SetViewMatrix(viewMatrix);
        
        glDisableVertexAttribArray(texturedProgram.positionAttribute);
        glDisableVertexAttribArray(texturedProgram.texCoordAttribute);
        glDisableVertexAttribArray(program.positionAttribute);
        
        SDL_GL_SwapWindow(displayWindow);
    }
    
    Mix_FreeChunk(ping1);
    Mix_FreeChunk(ping2);
    Mix_FreeChunk(burn);
    
    Mix_FreeMusic(music);
    
    SDL_Quit();
    return 0;
}





